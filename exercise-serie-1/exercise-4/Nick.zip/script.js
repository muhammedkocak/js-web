//Check to see if script is linked properly.
console.log("This script is linked properly!")


//Write your JS code here...
function calculate() {
  let now = new Date;
  let birth = document.getElementById(Date).value;
  console.log(birth);
}